# icsme26_test > 2026-02-22 7:25pm
https://universe.roboflow.com/emergencyvehicles/icsme26_test

Provided by a Roboflow user
License: CC BY 4.0

